#define DEFAULT_AcftType        1
#define DEFAULT_GeoidSepar     40
#define DEFAULT_CONbaud    115200
#define DEFAULT_PPSdelay      100
#define DEFAULT_FreqPlan        0
#define DEFAULT_DispPage        3

#define WIFI_ADDRESS_IP1        192
#define WIFI_ADDRESS_IP2        168
#define WIFI_ADDRESS_IP3        1
#define WIFI_ADDRESS_IP4        1
#define WIFI_ADDRESS_GW1        0
#define WIFI_ADDRESS_GW2        0
#define WIFI_ADDRESS_GW3        0
#define WIFI_ADDRESS_GW4        0
#define WIFI_ADDRESS_MK1        255
#define WIFI_ADDRESS_MK2        255
#define WIFI_ADDRESS_MK3        255
#define WIFI_ADDRESS_MK4        0

// #define WITH_HELTEC
// #define WITH_TTGO
#define WITH_TBEAM
// #define WITH_TBEAM_V10
// #define WITH_M5_JACEK
// #define WITH_FollowMe

// #define WITH_ILI9341
// #define WITH_ST7789
// #define WITH_TFT_LCD
// #define WITH_OLED
// #define WITH_OLED2
// #define WITH_U8G2_OLED
// #define WITH_U8G2_SH1106
// #define WITH_U8G2_FLIP

#define WITH_RFM95
// #define WITH_SX1262

// #define WITH_SLEEP

// #define WITH_AXP
// #define WITH_BQ

// #define WITH_LED_RX
// #define WITH_LED_TX

// #define WITH_GPS_ENABLE
// #define WITH_GPS_PPS
#define WITH_GPS_CONFIG

#define WITH_GPS_UBX
// #define WITH_GPS_MTK
// #define WITH_GPS_SRF
// #define WITH_MAVLINK

#define WITH_GPS_UBX_PASS
#define WITH_GPS_NMEA_PASS

// #define WITH_BMP180
// #define WITH_BMP280
#define WITH_BME280
// #define WITH_MS5607

#define WITH_PFLAA
// #define WITH_POGNT
#define WITH_LOOKOUT

#define WITH_CONFIG

// #define WITH_BEEPER
// #define WITH_SOUND

// #define WITH_KNOB
// #define WITH_VARIO

#define WITH_ADSL
#define WITH_PAW
#define WITH_FANET
#define WITH_LORAWAN

// #define WITH_AP
#define WITH_AP_BUTTON
#define WITH_BT_SPP
// #define WITH_STRATUX
// #define WITH_APRS

// #define WITH_HTTP

#define WITH_SPIFFS
#define WITH_SPIFFS_FAT
#define WITH_LOG
// #define WITH_SD
// #define WITH_SDLOG

// #define WITH_ENCRYPT

#if defined(WITH_STRATUX) || defined(WITH_APRS) || defined(WITH_AP)
#define WITH_WIFI
#endif

